(funciton(){
	alert("hello world")
})();